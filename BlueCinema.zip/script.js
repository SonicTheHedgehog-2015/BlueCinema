/* ================= CONFIG ================= */
const STORAGE_WARNING =
  "Warning: Installing the full native/offline application bundle may require significant local storage. Continue?";

// "" = local demo mode (uploads saved in THIS browser only).
// Set this to your real server to enable accounts, real publishing, billing,
// AI subtitle generation and server-side transcoded quality variants.
const API_URL = window.BLUECINEMA_API_URL || "";
const USE_BACKEND = window.BLUECINEMA_SERVER_MODE === true || Boolean(API_URL);

// These two owner accounts receive BluePremium without a paid subscription.
// IMPORTANT: mirror this allowlist on your real backend; client-side checks are not a security boundary.
const OWNER_PREMIUM_EMAILS = new Set([
  "blackholedevelopers2015@gmail.com",
  "muhammadsarimumair22@gmail.com"
]);
const FREE_FAVICON_URL = "https://plain-eeur-prod-public.komododecks.com/202610/08/O7BtGZm3MBW7S8wuE4YJ/image.png";
const PREMIUM_FAVICON_URL = "https://plain-eeur-prod-public.komododecks.com/202610/08/c3fI3mZyh3KXVTgJVjH3/image.png";

const SUBSCRIPTION = {
  name: "BluePremium",
  price: 15,
  checkoutUrl: "", // Set to your real Stripe/PayPal checkout URL.
  manageUrl: ""
};

// Native installer URLs. Point these to your actual signed builds when available.
// Until then the PWA installer below gives a working installable BlueCinema app
// on supported desktop/Android browsers without inventing download files.
const NATIVE_INSTALLERS = {
  windows: "",
  linux: "",
  macos: "",
  android: "",
  chromeos: "bluecinema-chromeos.deb",
  ios: ""
};

// Built-in movies (replace the URLs with your own cloud links).
// Optional premium variants can be supplied by the backend as stream720Url,
// stream1080Url, stream1440Url, stream2160Url and stream4320Url.
const builtInMovies = [
  { id: "b1", title: "Big Buck Bunny", size: "158 MB", visibility: "public", mine: false, ownerName: "BlueCinema", description: "A classic open movie demo hosted in the BlueCinema library.", publishedAt: "",
    streamUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    downloadUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4" },
  { id: "b2", title: "Elephants Dream", size: "170 MB", visibility: "public", mine: false, ownerName: "BlueCinema", description: "A classic open movie demo hosted in the BlueCinema library.", publishedAt: "",
    streamUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    downloadUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4" },
  { id: "b3", title: "Sintel", size: "181 MB", visibility: "public", mine: false, ownerName: "BlueCinema", description: "A classic open movie demo hosted in the BlueCinema library.", publishedAt: "",
    streamUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
    downloadUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4" }
];

/* ================= HELPERS ================= */
const $ = (s) => document.querySelector(s);
const player = $("#moviePlayer"), grid = $("#movieGrid"), titleEl = $("#nowPlayingTitle");
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now() + "-" + Math.random().toString(16).slice(2));
const fmtSize = (b) => b >= 1e9 ? (b / 1e9).toFixed(2) + " GB" : (b / 1e6).toFixed(1) + " MB";

function toast(msg) {
  const t = document.createElement("div");
  t.className = "toast"; t.textContent = msg;
  $("#toasts").appendChild(t);
  setTimeout(() => t.remove(), 4200);
}

/* ================= REQUIRED AUTH ================= */
let authMode = "signin";
let currentUser = null;
const AUTH_ACCOUNT_KEY = "bluecinema-account-v2";
const AUTH_SESSION_KEY = "bluecinema-session-v2";

async function hashPassword(value) {
  if (!window.crypto?.subtle) return btoa(unescape(encodeURIComponent(value)));
  const bytes = new TextEncoder().encode(value);
  const hash = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(hash)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function updateSiteFavicon() {
  const src = isOwnerPremium(currentUser?.email) || plan === "premium" ? PREMIUM_FAVICON_URL : FREE_FAVICON_URL;
  ["siteFavicon", "siteAppleIcon"].forEach((id) => { const node = document.getElementById(id); if (node) node.href = src; });
}

function setAuthUI(user) {
  currentUser = user || null;
  if (currentUser) plan = ownerOrStoredPlan(currentUser.email) ? "premium" : "free";
  else plan = "free";
  const signedIn = !!currentUser;
  document.body.classList.toggle("auth-locked", !signedIn);
  $("#authModal").hidden = signedIn;
  if (signedIn) {
    const label = currentUser.name || currentUser.email.split("@")[0];
    $("#accountLabel").textContent = label;
    $("#accountAvatar").textContent = label.slice(0,1).toUpperCase();
    $("#accountButton").title = `Signed in as ${currentUser.email} — click to sign out`;
  } else {
    $("#accountLabel").textContent = "Sign in";
    $("#accountAvatar").textContent = "?";
    $("#accountButton").title = "Sign in";
  }
  updateSiteFavicon();
  if (signedIn && document.getElementById("planPill")) setPlan(plan, false);
}

function showAuthError(message) {
  const e = $("#authError"); e.hidden = !message; e.textContent = message || "";
}

function setAuthMode(mode) {
  authMode = mode === "signup" ? "signup" : "signin";
  document.querySelectorAll(".auth-tab").forEach((b) => b.classList.toggle("active", b.dataset.authMode === authMode));
  $("#authNameWrap").hidden = authMode !== "signup";
  $("#authName").required = authMode === "signup";
  $("#authPassword").autocomplete = authMode === "signup" ? "new-password" : "current-password";
  $("#authSubmit").textContent = authMode === "signup" ? "Create account & continue" : "Sign in";
  $("#authTitle").textContent = authMode === "signup" ? "Create your BlueCinema account" : "Sign in to continue";
  $("#authSubtitle").textContent = authMode === "signup"
    ? "Create a local account now. Your real deployment can connect this form to your auth provider."
    : "Your account is required to watch, publish, download and manage movies.";
  showAuthError("");
}

async function localAuthSubmit({ name, email, password }) {
  const normalized = email.trim().toLowerCase();
  const hash = await hashPassword(password);
  if (authMode === "signup") {
    if (localStorage.getItem(AUTH_ACCOUNT_KEY)) throw new Error("A local BlueCinema account already exists. Sign in instead.");
    const account = { name: name.trim(), email: normalized, passwordHash: hash };
    localStorage.setItem(AUTH_ACCOUNT_KEY, JSON.stringify(account));
    localStorage.setItem(AUTH_SESSION_KEY, JSON.stringify({ name: account.name, email: account.email }));
    return { name: account.name, email: account.email };
  }
  const raw = localStorage.getItem(AUTH_ACCOUNT_KEY);
  if (!raw) throw new Error("No local account exists yet. Choose Create account first.");
  const account = JSON.parse(raw);
  if (account.email !== normalized || account.passwordHash !== hash) throw new Error("Incorrect email or password.");
  const session = { name: account.name, email: account.email };
  localStorage.setItem(AUTH_SESSION_KEY, JSON.stringify(session));
  return session;
}

async function bootstrapAuth() {
  if (USE_BACKEND) {
    try {
      const r = await fetch(API_URL + "/api/auth/session", { credentials: "include" });
      const data = r.ok ? await r.json() : { authenticated: false };
      if (data.authenticated) { setAuthUI(data.user || { email: "Account" }); return true; }
    } catch {}
    setAuthUI(null);
    return false;
  }
  try {
    const session = JSON.parse(localStorage.getItem(AUTH_SESSION_KEY) || "null");
    if (session?.email) { setAuthUI(session); return true; }
  } catch {}
  setAuthUI(null);
  return false;
}

$("#accountButton").addEventListener("click", async () => {
  if (!currentUser) { $("#authModal").hidden = false; setAuthMode("signin"); return; }
  if (confirm(`Sign out of ${currentUser.email}?`)) {
    if (USE_BACKEND) { try { await fetch(API_URL + "/api/auth/logout", { method: "POST", credentials: "include" }); } catch {} }
    localStorage.removeItem(AUTH_SESSION_KEY);
    setAuthUI(null);
  }
});

document.querySelectorAll(".auth-tab").forEach((b) => b.addEventListener("click", () => setAuthMode(b.dataset.authMode)));
$("#authForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  showAuthError("");
  const btn = $("#authSubmit");
  btn.disabled = true; btn.textContent = authMode === "signup" ? "Creating account…" : "Signing in…";
  try {
    let user;
    const name = $("#authName").value;
    const email = $("#authEmail").value;
    const password = $("#authPassword").value;
    if (USE_BACKEND) {
      const endpoint = authMode === "signup" ? "/api/auth/register" : "/api/auth/login";
      const r = await fetch(API_URL + endpoint, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name, email, password }) });
      const data = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(data.message || "Authentication failed.");
      user = data.user || { name: data.name || name, email };
    } else {
      user = await localAuthSubmit({ name, email, password });
    }
    setAuthUI(user);
    $("#authForm").reset();
    toast(`Welcome${user.name ? `, ${user.name}` : ""}!`);
    await refresh();
  } catch (err) {
    showAuthError(err.message || "Authentication failed.");
  } finally {
    btn.disabled = false;
    btn.textContent = authMode === "signup" ? "Create account & continue" : "Sign in";
  }
});

/* ================= PLANS ================= */
let plan = "free";
function planStorageKey(email = currentUser?.email || "guest") { return `bluecinema-plan:${String(email).trim().toLowerCase()}`; }
function isOwnerPremium(email = currentUser?.email) { return !!email && OWNER_PREMIUM_EMAILS.has(String(email).trim().toLowerCase()); }
function ownerOrStoredPlan(email = currentUser?.email) { return isOwnerPremium(email) || localStorage.getItem(planStorageKey(email)) === "premium"; }
let currentQuality = "720p";
let currentFps = 30;
let currentSubtitleMode = "embedded";
let currentSubtitleLanguage = "en";

const QUALITY_LEVELS = { "720p": 720, "1080p": 1080, "1440p": 1440, "2160p": 2160, "4320p": 4320 };
const FPS_LEVELS = [30, 60, 120, 150];
const QUALITY_KEYS = { 720: "stream720Url", 1080: "stream1080Url", 1440: "stream1440Url", 2160: "stream2160Url", 4320: "stream4320Url" };

function getDeviceVideoCaps() {
  const w = Math.max(screen.width, screen.height) * (window.devicePixelRatio || 1);
  const h = Math.min(4320, Math.max(720, Math.round(w)));
  const memory = navigator.deviceMemory || 4;
  const cores = navigator.hardwareConcurrency || 4;
  const maxHeight = memory >= 16 && cores >= 8 ? 4320 : memory >= 8 && cores >= 6 ? 2160 : memory >= 4 && cores >= 4 ? 1440 : 1080;
  const maxFps = memory >= 12 && cores >= 8 ? 150 : memory >= 8 && cores >= 6 ? 120 : memory >= 4 && cores >= 4 ? 60 : 30;
  return { displayHeight: h, maxHeight, maxFps };
}

function isPremium() { return plan === "premium" || isOwnerPremium(currentUser?.email); }

function setPlan(next, persist = true) {
  plan = next === "premium" ? "premium" : "free";
  if (persist && currentUser?.email) localStorage.setItem(planStorageKey(currentUser.email), plan);
  if (isOwnerPremium(currentUser?.email)) plan = "premium";
  $("#planPill").textContent = plan === "premium" ? "PREMIUM" : "FREE";
  $("#planPill").classList.toggle("premium", plan === "premium");
  $("#upgradeBtn").hidden = plan === "premium";
  $("#managePlanBtn").hidden = plan !== "premium";
  $("#premiumBadge").hidden = plan !== "premium";
  $("#billingNote").textContent = plan === "premium"
    ? "BluePremium is active on this browser."
    : "Demo checkout is enabled until a real billing URL is configured.";
  document.querySelectorAll(".premium-option").forEach((o) => { o.disabled = !isPremium(); });
  if (!isPremium()) {
    currentQuality = "720p";
    currentFps = 30;
    currentSubtitleMode = currentSubtitleMode === "ai" ? "embedded" : currentSubtitleMode;
  }
  $("#qualitySelect").value = currentQuality;
  $("#fpsSelect").value = String(currentFps);
  $("#subtitleSelect").value = currentSubtitleMode;
  $("#subtitleLanguageSelect").value = currentSubtitleLanguage;
  $("#subtitleLanguageWrap").hidden = currentSubtitleMode !== "ai" || !isPremium();
  updateCapabilityNote();
  updateQualityBadge();
}

function upgradePlan() {
  if (SUBSCRIPTION.checkoutUrl) {
    window.location.href = SUBSCRIPTION.checkoutUrl;
    return;
  }
  // Deliberately local for testing. Replace checkoutUrl with your real payment flow.
  setPlan("premium");
  toast("✨ BluePremium enabled for testing. Connect a real checkout URL for payments.");
}

$("#upgradeBtn").addEventListener("click", upgradePlan);
$("#managePlanBtn").addEventListener("click", () => {
  if (SUBSCRIPTION.manageUrl) window.location.href = SUBSCRIPTION.manageUrl;
  else toast("Add SUBSCRIPTION.manageUrl to connect your billing portal.");
});

function updateCapabilityNote() {
  const caps = getDeviceVideoCaps();
  const requestedH = QUALITY_LEVELS[currentQuality];
  const actualH = Math.min(requestedH, isPremium() ? caps.maxHeight : 720);
  const actualFps = Math.min(currentFps, isPremium() ? caps.maxFps : 30);
  $("#capabilityNote").textContent = isPremium()
    ? `Your device is estimated to support up to ${actualH >= 4320 ? "8K" : actualH + "p"} and ${actualFps} FPS for this session.`
    : "Free plan is capped at 720p and 30 FPS. Upgrade to BluePremium for higher tiers on supported devices.";
}

function updateQualityBadge() {
  $("#qualityBadge").textContent = `${currentQuality} • ${currentFps} FPS`;
}

$("#qualitySelect").addEventListener("change", (e) => {
  if (!isPremium() && e.target.value !== "720p") {
    e.target.value = "720p";
    return toast("BluePremium is required above 720p.");
  }
  currentQuality = e.target.value;
  updateCapabilityNote();
  updateQualityBadge();
  if (currentId) playMovie(currentId, false);
});
$("#fpsSelect").addEventListener("change", (e) => {
  const n = Number(e.target.value);
  if (!isPremium() && n > 30) {
    e.target.value = "30";
    return toast("BluePremium is required above 30 FPS.");
  }
  currentFps = n;
  updateCapabilityNote();
  updateQualityBadge();
});
$("#subtitleSelect").addEventListener("change", async (e) => {
  const mode = e.target.value;
  if (mode === "ai" && !isPremium()) {
    e.target.value = "embedded";
    return toast("AI subtitles are a BluePremium feature.");
  }
  currentSubtitleMode = mode;
  $("#subtitleLanguageWrap").hidden = mode !== "ai" || !isPremium();
  if (currentId) await applySubtitles(library.find((m) => m.id === currentId));
});
$("#subtitleLanguageSelect").addEventListener("change", async (e) => {
  currentSubtitleLanguage = e.target.value;
  if (currentSubtitleMode === "ai" && currentId) await applySubtitles(library.find((m) => m.id === currentId));
});

/* ================= BACKEND ADAPTER ================= */
/*
 Server mode contract (recommended):
  GET    /api/me/subscription -> { plan: "free"|"premium", status: "active"|"trialing" }
  GET    /api/movies -> all public movies + the logged-in user's private movies; each movie should include ownerName, description, publishedAt, visibility, stream/download URLs and quality/subtitle metadata
  POST   /api/movies -> multipart: title, description, visibility, file
                 The server should derive ownerName from the authenticated user's profile and stamp publishedAt.
  PATCH  /api/movies/:id -> {visibility}
  DELETE /api/movies/:id
  POST   /api/ai/movies/generate -> { prompt, durationMinutes, style, language, autoSubtitles, aiGenerated } -> { message, movie? }
  POST   /api/movies/:id/subtitles/generate -> { language }
  GET    /api/movies/:id/subtitles/:lang -> WebVTT or JSON transcript/segments
  POST   /api/billing/create-checkout-session -> { url }

 The server should enforce the free/premium limits; the browser UI is not a
 security boundary. AI subtitle generation and 8K/150-FPS transcoding belong
 on the server/GPU side rather than inside a static HTML page.
*/
const objectUrls = [];
const posterObjectUrls = [];

const idb = new Promise((resolve, reject) => {
  if (USE_BACKEND) return resolve(null);
  const DB_NAME = "bluecinema";
  const STORE_NAME = "movies";
  const openCurrent = () => {
    const req = indexedDB.open(DB_NAME);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) db.createObjectStore(STORE_NAME, { keyPath: "id" });
    };
    req.onerror = () => reject(req.error || new Error("Could not open local database"));
    req.onsuccess = () => {
      const db = req.result;
      if (db.objectStoreNames.contains(STORE_NAME)) return resolve(db);
      const nextVersion = db.version + 1;
      db.close();
      const upgradeReq = indexedDB.open(DB_NAME, nextVersion);
      upgradeReq.onupgradeneeded = () => {
        const upgradedDb = upgradeReq.result;
        if (!upgradedDb.objectStoreNames.contains(STORE_NAME)) upgradedDb.createObjectStore(STORE_NAME, { keyPath: "id" });
      };
      upgradeReq.onerror = () => reject(upgradeReq.error || new Error("Could not upgrade local database"));
      upgradeReq.onsuccess = () => resolve(upgradeReq.result);
    };
  };
  openCurrent();
});

const tx = async (mode, fn) => {
  const d = await idb;
  return new Promise((res, rej) => {
    const t = d.transaction("movies", mode);
    const req = fn(t.objectStore("movies"));
    t.oncomplete = () => res(req.result);
    t.onerror = () => rej(t.error);
  });
};

const Backend = USE_BACKEND ? {
  async me() {
    try {
      const r = await fetch(API_URL + "/api/me/subscription", { credentials: "include" });
      if (!r.ok) return { plan: "free" };
      return await r.json();
    } catch { return { plan: "free" }; }
  },
  async list() {
    const r = await fetch(API_URL + "/api/movies", { credentials: "include" });
    if (!r.ok) throw new Error("Could not load movies");
    return (await r.json()).map((m) => ({ ...m, size: m.size || fmtSize(m.sizeBytes), ownerName: m.ownerName || m.authorName || "BlueCinema creator", description: m.description || "", publishedAt: m.publishedAt || "", posterType: m.posterType || "letter", posterGradient: Number.isFinite(Number(m.posterGradient)) ? Number(m.posterGradient) : 0, posterLetter: m.posterLetter || (m.title || "M").charAt(0).toUpperCase() }));
  },
  add(meta, file, onProgress) {
    return new Promise((res, rej) => {
      const fd = new FormData(); fd.append("title", meta.title); fd.append("description", meta.description || ""); fd.append("visibility", meta.visibility); fd.append("posterType", meta.posterType || "letter"); fd.append("posterGradient", String(meta.posterGradient ?? 0)); fd.append("posterLetter", meta.posterLetter || (meta.title || "M").charAt(0).toUpperCase()); if (meta.coverFile) fd.append("poster", meta.coverFile, meta.coverFile.name || "cover.png"); fd.append("aiGenerated", meta.aiGenerated ? "1" : "0"); fd.append("aiPrompt", meta.aiPrompt || ""); fd.append("aiDurationMinutes", String(meta.aiDurationMinutes || 0)); fd.append("aiStyle", meta.aiStyle || ""); fd.append("aiLanguage", meta.aiLanguage || ""); fd.append("file", file);
      const x = new XMLHttpRequest(); x.open("POST", API_URL + "/api/movies"); x.withCredentials = true;
      x.upload.onprogress = (e) => e.lengthComputable && onProgress(e.loaded / e.total);
      x.onload = () => (x.status < 300 ? res() : rej(new Error(x.status === 403 ? "Your plan does not allow this upload." : "Upload failed")));
      x.onerror = () => rej(new Error("Network error")); x.send(fd);
    });
  },
  remove: (id) => fetch(`${API_URL}/api/movies/${id}`, { method: "DELETE", credentials: "include" }),
  setVisibility: (id, v) => fetch(`${API_URL}/api/movies/${id}`, { method: "PATCH", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ visibility: v }) }),
  async generateSubtitle(movieId, lang) {
    const r = await fetch(`${API_URL}/api/movies/${movieId}/subtitles/generate`, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ language: lang }) });
    if (!r.ok) throw new Error("AI subtitle generation is unavailable right now.");
    return r.json();
  },
  async generateMovie(payload) {
    const r = await fetch(`${API_URL}/api/ai/movies/generate`, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.message || "AI movie generation is unavailable right now.");
    return data;
  },
  async getAiMovieJob(jobId) {
    const r = await fetch(`${API_URL}/api/ai/movies/jobs/${encodeURIComponent(jobId)}`, { credentials: "include" });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.message || "Could not read AI generation status.");
    return data;
  }
} : {
  async me() { return { plan: ownerOrStoredPlan(currentUser?.email) ? "premium" : "free" }; },
  async list() {
    objectUrls.splice(0).forEach(URL.revokeObjectURL);
    posterObjectUrls.splice(0).forEach(URL.revokeObjectURL);
    return (await tx("readonly", (s) => s.getAll())).map((r) => {
      const url = URL.createObjectURL(r.blob); objectUrls.push(url);
      const posterUrl = r.posterBlob ? URL.createObjectURL(r.posterBlob) : "";
      if (posterUrl) posterObjectUrls.push(posterUrl);
      return { id: r.id, title: r.title, size: fmtSize(r.blob.size), visibility: r.visibility, mine: true, streamUrl: url, downloadUrl: url, fileName: r.fileName, description: r.description || "", ownerName: r.ownerName || currentUser?.name || "You", publishedAt: r.publishedAt || "", embeddedSubtitles: r.embeddedSubtitles || [], aiGenerated: !!r.aiGenerated, aiPrompt: r.aiPrompt || "", aiDurationMinutes: r.aiDurationMinutes || 0, aiStyle: r.aiStyle || "", aiLanguage: r.aiLanguage || "", aiGeneratedAt: r.aiGeneratedAt || "", posterUrl, posterType: r.posterType || "letter", posterGradient: Number.isFinite(r.posterGradient) ? r.posterGradient : 0, posterLetter: r.posterLetter || (r.title || "M").charAt(0).toUpperCase() };
    });
  },
  async add(meta, file, onProgress) {
    await tx("readwrite", (s) => s.put({ id: uid(), title: meta.title, description: meta.description || "", visibility: meta.visibility, ownerName: currentUser?.name || "You", publishedAt: new Date().toISOString(), fileName: file.name, blob: file, posterBlob: meta.coverFile || null, posterType: meta.posterType || "letter", posterGradient: Number(meta.posterGradient || 0), posterLetter: meta.posterLetter || (meta.title || "M").charAt(0).toUpperCase(), embeddedSubtitles: [], aiGenerated: !!meta.aiGenerated, aiPrompt: meta.aiPrompt || "", aiDurationMinutes: meta.aiDurationMinutes || 0, aiStyle: meta.aiStyle || "", aiLanguage: meta.aiLanguage || "", aiGeneratedAt: meta.aiGeneratedAt || "" }));
    if (typeof onProgress === "function") onProgress(1);
  },
  async generateMovie(payload) {
    throw new Error("Run the included BlueCinema server to generate AI movies with Krea.");
  },
  async getAiMovieJob() {
    throw new Error("AI movie jobs require the BlueCinema server.");
  },
  remove: (id) => tx("readwrite", (s) => s.delete(id)),
  async setVisibility(id, v) { const row = await tx("readonly", (s) => s.get(id)); row.visibility = v; await tx("readwrite", (s) => s.put(row)); }
};

/* ================= APP INSTALLATION ================= */
let deferredInstallPrompt = null;

function detectOS() {
  const ua = navigator.userAgent.toLowerCase();
  if (/iphone|ipad|ipod/.test(ua)) return "ios";
  if (/android/.test(ua)) return "android";
  if (/cros/.test(ua)) return "chromeos";
  if (/windows/.test(ua)) return "windows";
  if (/mac os x/.test(ua)) return "macos";
  if (/linux/.test(ua)) return "linux";
  return "other";
}

function appInstruction(os) {
  const map = {
    windows: "Windows is detected. The install button uses the native installer when configured; otherwise it installs BlueCinema as a desktop PWA.",
    macos: "macOS is detected. The native .dmg is used when configured; otherwise install BlueCinema as a PWA.",
    linux: "Linux is detected. The native package is used when configured; otherwise install BlueCinema as a PWA.",
    android: "Android is detected. Use the APK when configured, otherwise use the browser's Install App prompt.",
    chromeos: "ChromeOS is detected. Download the BlueCinema .deb for the Linux environment, or install the PWA for the lightest setup.",
    ios: "iPhone/iPad detected. Use Share → Add to Home Screen for the BlueCinema app experience.",
    other: "Your device can use the web app. Install BlueCinema as a PWA when your browser supports it."
  };
  return map[os] || map.other;
}

function downloadNative(os) {
  const url = NATIVE_INSTALLERS[os];
  if (!url) return false;
  const a = document.createElement("a");
  a.href = url; a.rel = "noopener";
  document.body.appendChild(a); a.click(); a.remove();
  return true;
}

window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault(); deferredInstallPrompt = e;
  $("#installAppBtn").classList.add("install-highlight");
});

window.addEventListener("appinstalled", () => {
  deferredInstallPrompt = null;
  $("#installAppLabel").textContent = "BlueCinema Installed";
  toast("✅ BlueCinema was installed successfully.");
});

$("#installAppBtn").addEventListener("click", async () => {
  const os = detectOS();
  if (downloadNative(os)) return;
  if (deferredInstallPrompt) {
    deferredInstallPrompt.prompt();
    await deferredInstallPrompt.userChoice;
    deferredInstallPrompt = null;
    return;
  }
  if (os === "ios") return toast("On iPhone/iPad use Share → Add to Home Screen.");
  toast("This browser does not expose the install prompt. Use the browser menu and choose Install App / Add to Home Screen.");
});

document.querySelectorAll("[data-native-os]").forEach((btn) => {
  btn.addEventListener("click", () => {
    const os = btn.dataset.nativeOs;
    if (!downloadNative(os)) {
      toast(`The ${os} native installer is not configured yet. The main Install App button can use the PWA instead.`);
    }
  });
});

const detectedOS = detectOS();
const prettyOS = { windows: "Windows", macos: "macOS", linux: "Linux", android: "Android", chromeos: "ChromeOS", ios: "iPhone/iPad", other: "your device" };
$("#installAppLabel").textContent = `Install BlueCinema on ${prettyOS[detectedOS] || prettyOS.other}`;
$("#appNote").textContent = appInstruction(detectedOS);
document.querySelectorAll("[data-native-os]").forEach((btn) => {
  if (btn.dataset.nativeOs === detectedOS) btn.classList.add("install-highlight");
});

/* ================= LIBRARY ================= */
const gradients = [
  "linear-gradient(135deg,#8b5cf6,#3b82f6,#22d3ee)", "linear-gradient(135deg,#6d28d9,#2563eb,#06b6d4)",
  "linear-gradient(135deg,#22d3ee,#3b82f6,#8b5cf6)", "linear-gradient(135deg,#a78bfa,#38bdf8,#2dd4bf)"
];
let library = [], filter = "all", currentId = null, searchTerm = "";
let hiddenMovieIds = new Set(JSON.parse(localStorage.getItem("bluecinema-hidden-movies") || "[]"));
let contextMovie = null;

function visibleMovies() {
  const q = searchTerm.trim().toLowerCase();
  return library.filter((m) => {
    if (hiddenMovieIds.has(m.id)) return false;
    const byFilter = filter === "mine" ? m.mine : filter === "public" ? m.visibility === "public" : (m.visibility === "public" || m.mine);
    const haystack = `${m.title || ""} ${m.description || ""} ${m.ownerName || ""} ${m.aiGenerated ? "ai generated" : ""} ${m.aiStyle || ""}`.toLowerCase();
    return byFilter && (!q || haystack.includes(q));
  });
}
function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text) e.textContent = text; return e; }

function createCard(m, i) {
  const card = el("article", "movie-card");
  card.dataset.id = m.id; card.style.animationDelay = i * 70 + "ms";
  if (m.id === currentId) card.classList.add("active");
  card.addEventListener("contextmenu", (e) => {
    e.preventDefault();
    contextMovie = m;
    if (m.aiGenerated) openAiMovieContextMenu(e.clientX, e.clientY, m);
    else openMovieContextMenu(e.clientX, e.clientY, m);
  });

  const play = el("button", "movie-play"); play.type = "button"; play.setAttribute("aria-label", "Play " + m.title);
  const thumb = el("div", "thumb");
  const posterGradient = gradients[Math.abs(Number(m.posterGradient ?? i)) % gradients.length];
  const posterIsImage = !!m.posterUrl;
  if (posterIsImage) { thumb.classList.add("has-poster"); thumb.style.backgroundImage = `url("${String(m.posterUrl).replace(/"/g, '%22')}")`; }
  else thumb.style.backgroundImage = posterGradient;
  if (!posterIsImage) thumb.append(el("span", "thumb-letter", (m.posterLetter || m.title || "M").charAt(0).toUpperCase()));
  if (m.mine && !m.id.startsWith("b")) thumb.prepend(el("span", "badge", m.visibility === "private" ? "🔒 Private" : "🌐 Public"));
  if (m.aiGenerated) thumb.append(el("span", "badge ai-badge", "✨ AI GENERATED"));
  if (m.aiSubtitles) thumb.append(el("span", "badge", "🪄 AI subs"));
  const info = el("div", "movie-info");
  const title = el("h3", "movie-title", m.title);
  const publisher = el("p", "movie-publisher", `${m.visibility === "public" ? "Published by" : "Uploaded by"} ${m.ownerName || "BlueCinema creator"}`);
  const description = el("p", "movie-description", m.description || "No description added.");
  const meta = el("p", "movie-size", m.size);
  info.append(title, publisher, description, meta);
  play.append(thumb, info);
  play.addEventListener("click", () => playMovie(m.id));

  const actions = el("div", "movie-actions");
  const dl = el("a", "btn btn-download", "Download Movie File (.mp4/.mkv)");
  dl.href = m.downloadUrl; dl.setAttribute("download", m.fileName || ""); dl.rel = "noopener";
  actions.append(dl);

  if (m.mine && !m.id.startsWith("b")) {
    const row = el("div", "owner-row");
    const tog = el("button", "btn btn-mini", m.visibility === "private" ? "Make Public" : "Make Private"); tog.type = "button";
    tog.onclick = async () => { await Backend.setVisibility(m.id, m.visibility === "private" ? "public" : "private"); toast("Visibility updated"); refresh(); };
    const del = el("button", "btn btn-mini danger", "Delete"); del.type = "button";
    del.onclick = async () => { if (confirm('Delete "' + m.title + '"?')) { await Backend.remove(m.id); toast("Movie deleted"); refresh(); } };
    row.append(tog, del); actions.append(row);
  }
  card.append(play, actions);
  card.addEventListener("mousemove", (e) => {
    const r = card.getBoundingClientRect();
    card.style.setProperty("--ry", ((e.clientX - r.left) / r.width - .5) * 10 + "deg");
    card.style.setProperty("--rx", (.5 - (e.clientY - r.top) / r.height) * 10 + "deg");
  });
  card.addEventListener("mouseleave", () => { card.style.setProperty("--rx", "0deg"); card.style.setProperty("--ry", "0deg"); });
  return card;
}


function closeAiMovieContextMenu() {
  const menu = $("#aiMovieContextMenu");
  if (menu) menu.hidden = true;
}
function openAiMovieContextMenu(x, y, movie) {
  closeMovieContextMenu();
  const menu = $("#aiMovieContextMenu");
  contextMovie = movie;
  menu.hidden = false;
  menu.querySelector('[data-ai-action="delete"]').hidden = !(movie.mine && !String(movie.id).startsWith("b"));
  const margin = 10;
  const rectW = menu.offsetWidth || 280, rectH = menu.offsetHeight || 300;
  menu.style.left = `${Math.min(x, window.innerWidth - rectW - margin)}px`;
  menu.style.top = `${Math.min(y, window.innerHeight - rectH - margin)}px`;
  menu.querySelector("button")?.focus();
}

$("#aiMovieContextMenu").addEventListener("click", async (e) => {
  const btn = e.target.closest("button[data-ai-action]");
  if (!btn || !contextMovie) return;
  const movie = contextMovie;
  const action = btn.dataset.aiAction;
  closeAiMovieContextMenu();
  if (action === "play") return playMovie(movie.id);
  if (action === "info") return openMovieInfo(movie);
  if (action === "download") { const a = document.createElement("a"); a.href = movie.downloadUrl || movie.streamUrl; a.download = movie.fileName || "ai-movie"; a.rel = "noopener"; document.body.appendChild(a); a.click(); a.remove(); return; }
  if (action === "subtitles") { if (!isPremium()) return toast("🪄 AI subtitles require BluePremium."); if (!USE_BACKEND) return toast("Run BlueCinema with its server to generate AI subtitles."); return applySubtitles(movie); }
  if (action === "hide") { hiddenMovieIds.add(movie.id); persistHiddenMovies(); render(); toast(`“${movie.title}” hidden from your library.`); return; }
  if (action === "delete") {
    if (!(movie.mine && !String(movie.id).startsWith("b"))) return;
    if (confirm(`Permanently delete “${movie.title}”? This cannot be undone.`)) { try { await Backend.remove(movie.id); await refresh(); toast("AI movie permanently deleted."); } catch (err) { toast(`Delete failed: ${err.message || "Unknown error"}`); } }
  }
});
function openMovieInfo(movie) {
  const modal = $("#movieInfoModal");
  $("#movieInfoTitle").textContent = movie.title || "Movie";
  $("#movieInfoByline").textContent = `${movie.visibility === "public" ? "Published by" : "Uploaded by"} ${movie.ownerName || "BlueCinema creator"}`;
  $("#movieInfoDescription").textContent = movie.description || "No description added.";
  const stats = $("#movieInfoStats");
  stats.innerHTML = "";
  [
    ["Visibility", movie.visibility === "public" ? "Public" : "Private"],
    ["File size", movie.size || "Unknown"],
    ["Published", movie.publishedAt ? new Date(movie.publishedAt).toLocaleDateString() : "Date unavailable"],
    ["Subtitles", movie.aiSubtitles ? "AI subtitles available" : (movie.embeddedSubtitles?.length ? "Embedded subtitles" : "Included with file")],
    ["AI generated", movie.aiGenerated ? `Yes • ${movie.aiDurationMinutes || ""} min • ${movie.aiStyle || "Cinematic"}` : "No"]
  ].forEach(([label, value]) => {
    const item = el("div", "movie-stat");
    item.append(el("span", "movie-stat-label", label), el("strong", "movie-stat-value", value));
    stats.append(item);
  });
  modal.hidden = false;
}

function closeMovieInfo() { $("#movieInfoModal").hidden = true; }
$("#closeMovieInfo").addEventListener("click", closeMovieInfo);
$("#movieInfoModal").addEventListener("click", (e) => { if (e.target.id === "movieInfoModal") closeMovieInfo(); });

function render() {
  grid.innerHTML = "";
  const list = visibleMovies();
  if (!list.length) return grid.append(el("p", "empty", searchTerm ? "No movies match your search. 🔎" : "Nothing here yet. Upload your first movie! 🎬"));
  list.forEach((m, i) => grid.appendChild(createCard(m, i)));
}

/* ================= SEARCH + CONTEXT MENU ================= */
function persistHiddenMovies() {
  localStorage.setItem("bluecinema-hidden-movies", JSON.stringify([...hiddenMovieIds]));
}

function closeMovieContextMenu() {
  $("#movieContextMenu").hidden = true;
  contextMovie = null;
}

function openMovieContextMenu(x, y, movie) {
  const menu = $("#movieContextMenu");
  menu.hidden = false;
  menu.querySelector('[data-action="delete"]').hidden = !(movie.mine && !String(movie.id).startsWith("b"));
  const margin = 10;
  const rectW = menu.offsetWidth || 250, rectH = menu.offsetHeight || 260;
  menu.style.left = `${Math.min(x, window.innerWidth - rectW - margin)}px`;
  menu.style.top = `${Math.min(y, window.innerHeight - rectH - margin)}px`;
  menu.querySelector("button")?.focus();
}

$("#movieContextMenu").addEventListener("click", async (e) => {
  const btn = e.target.closest("button[data-action]");
  if (!btn || !contextMovie) return;
  const movie = contextMovie;
  const action = btn.dataset.action;
  closeMovieContextMenu();
  if (action === "play") return playMovie(movie.id);
  if (action === "newtab") {
    if (movie.streamUrl) window.open(movie.streamUrl, "_blank", "noopener");
    return;
  }
  if (action === "download") {
    const a = document.createElement("a"); a.href = movie.downloadUrl || movie.streamUrl; a.download = movie.fileName || "movie"; a.rel = "noopener"; document.body.appendChild(a); a.click(); a.remove(); return;
  }
  if (action === "copy") {
    try { await navigator.clipboard.writeText(movie.streamUrl || movie.downloadUrl || ""); toast("Movie link copied."); } catch { toast("Could not copy the movie link on this browser."); }
    return;
  }
  if (action === "info") {
    openMovieInfo(movie);
    return;
  }
  if (action === "hide") {
    hiddenMovieIds.add(movie.id); persistHiddenMovies();
    if (currentId === movie.id) { player.pause(); currentId = null; player.removeAttribute("src"); player.load(); titleEl.textContent = "Select a movie below"; updateSelectedMoviePanel(null); }
    render(); toast(`“${movie.title}” hidden from your library.`);
    return;
  }
  if (action === "delete") {
    if (!(movie.mine && !String(movie.id).startsWith("b"))) return;
    if (confirm(`Permanently delete “${movie.title}”? This cannot be undone.`)) {
      try { await Backend.remove(movie.id); hiddenMovieIds.delete(movie.id); persistHiddenMovies(); toast("Movie permanently deleted."); await refresh(); }
      catch (err) { toast(`Delete failed: ${err.message || "Unknown error"}`); }
    }
  }
});

document.addEventListener("click", (e) => {
  if (!e.target.closest("#movieContextMenu")) closeMovieContextMenu();
  if (!e.target.closest("#aiMovieContextMenu")) closeAiMovieContextMenu();
});
window.addEventListener("scroll", () => { closeMovieContextMenu(); closeAiMovieContextMenu(); }, { passive: true });
window.addEventListener("resize", () => { closeMovieContextMenu(); closeAiMovieContextMenu(); });
document.addEventListener("keydown", (e) => { if (e.key === "Escape") { closeMovieContextMenu(); closeAiMovieContextMenu(); } });

const movieSearchInput = $("#movieSearch");
function runMovieSearch(value) { searchTerm = String(value || ""); render(); }
movieSearchInput.addEventListener("input", (e) => runMovieSearch(e.target.value));
movieSearchInput.addEventListener("search", (e) => runMovieSearch(e.target.value));
movieSearchInput.addEventListener("change", (e) => runMovieSearch(e.target.value));
window.addEventListener("keydown", (e) => { if (e.key === "/" && document.activeElement !== movieSearchInput) { e.preventDefault(); movieSearchInput.focus(); } });
$("#clearHiddenMovies").addEventListener("click", () => {
  if (!hiddenMovieIds.size) return toast("No hidden movies to restore.");
  hiddenMovieIds.clear(); persistHiddenMovies(); render(); toast("Hidden movies restored.");
});

async function refresh() {
  try {
    const me = await Backend.me();
    if (USE_BACKEND) setPlan(isOwnerPremium(currentUser?.email) ? "premium" : (me.plan === "premium" ? "premium" : "free"), false); else setPlan(ownerOrStoredPlan(currentUser?.email) ? "premium" : "free", false);
    library = [...builtInMovies, ...(await Backend.list())];
  } catch (err) {
    library = [...builtInMovies];
    toast("Could not load your uploads");
  }
  render();
}

function pickVariant(movie) {
  if (!isPremium()) return movie.stream720Url || movie.streamUrl;
  const caps = getDeviceVideoCaps();
  let requested = QUALITY_LEVELS[currentQuality];
  requested = Math.min(requested, caps.maxHeight);
  const candidates = [4320,2160,1440,1080,720];
  const selected = candidates.find((h) => h <= requested && movie[QUALITY_KEYS[h]]) || 720;
  return movie[QUALITY_KEYS[selected]] || movie.streamUrl;
}

/* ================= AUDIO BOOST ================= */
let audioContext = null, mediaSource = null, audioGain = null, audioCompressor = null;
async function ensureAudioBoost() {
  if (audioContext) { if (audioContext.state === "suspended") await audioContext.resume(); return true; }
  try {
    player.crossOrigin = "anonymous";
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) throw new Error("Web Audio is unavailable");
    audioContext = new Ctx();
    mediaSource = audioContext.createMediaElementSource(player);
    audioGain = audioContext.createGain();
    audioCompressor = audioContext.createDynamicsCompressor();
    audioCompressor.threshold.value = -18;
    audioCompressor.knee.value = 18;
    audioCompressor.ratio.value = 6;
    audioCompressor.attack.value = 0.006;
    audioCompressor.release.value = 0.12;
    audioGain.gain.value = Number($("#audioBoost").value) / 100;
    mediaSource.connect(audioGain).connect(audioCompressor).connect(audioContext.destination);
    await audioContext.resume();
    return true;
  } catch (err) {
    audioContext = null; mediaSource = null; audioGain = null; audioCompressor = null;
    toast("Audio boost is unavailable for this movie/browser. Standard player volume still works.");
    return false;
  }
}

$("#audioBoost").addEventListener("input", async (e) => {
  const n = Number(e.target.value);
  $("#audioBoostValue").value = `${n}%`;
  $("#audioBoostValue").textContent = `${n}%`;
  if (await ensureAudioBoost()) audioGain.gain.setTargetAtTime(n / 100, audioContext.currentTime, 0.03);
});

function updateSelectedMoviePanel(movie) {
  const panel = $("#selectedMoviePanel");
  if (!panel) return;
  if (!movie) { panel.hidden = true; return; }
  panel.hidden = false;
  const selectedPoster = $("#selectedMoviePoster");
  selectedPoster.classList.remove("has-poster");
  selectedPoster.style.backgroundImage = gradients[Math.abs(Number(movie.posterGradient ?? 0)) % gradients.length];
  if (movie.posterUrl) { selectedPoster.classList.add("has-poster"); selectedPoster.style.backgroundImage = `url("${String(movie.posterUrl).replace(/"/g, '%22')}")`; }
  $("#selectedMovieLetter").textContent = movie.posterUrl ? "" : (movie.posterLetter || movie.title || "M").charAt(0).toUpperCase();
  $("#selectedMovieName").textContent = movie.title || "Movie";
  $("#selectedMovieByline").textContent = `${movie.visibility === "public" ? "Published by" : "Uploaded by"} ${movie.ownerName || "BlueCinema creator"}`;
  $("#selectedMovieDescription").textContent = movie.description || "No description added.";
  const badges = $("#selectedMovieBadges"); badges.innerHTML = "";
  const addBadge = (text, premium = false) => { const b = el("span", premium ? "premium-tag" : "", text); badges.appendChild(b); };
  addBadge(movie.visibility === "public" ? "🌐 Public" : "🔒 Private");
  if (movie.aiGenerated) addBadge("✨ AI GENERATED", true);
  if (movie.aiSubtitles) addBadge("🪄 AI subtitles", true);
  const stats = $("#selectedMovieStats"); stats.innerHTML = "";
  [
    ["File size", movie.size || "Unknown"],
    ["Published", movie.publishedAt ? new Date(movie.publishedAt).toLocaleDateString() : "Date unavailable"],
    ["Subtitles", movie.aiSubtitles ? "AI + embedded" : (movie.embeddedSubtitles?.length ? "Embedded" : "Included")],
    ["AI movie", movie.aiGenerated ? `Yes • ${movie.aiDurationMinutes || ""} min` : "No"],
    ["Plan", isPremium() ? "BluePremium" : "Free"]
  ].forEach(([label, value]) => {
    const item = el("div", "selected-movie-stat");
    item.append(el("span", null, label), el("strong", null, value));
    stats.appendChild(item);
  });
}

async function playMovie(id, scroll = true) {
  const m = library.find((x) => x.id === id); if (!m) return;
  currentId = id;
  if (!isPremium()) { currentQuality = "720p"; currentFps = 30; }
  await ensureAudioBoost();
  player.src = pickVariant(m);
  player.load();
  if (scroll) player.play().catch(() => {});
  titleEl.textContent = m.title;
  updateSelectedMoviePanel(m);
  updateQualityBadge(); updateCapabilityNote();
  await applySubtitles(m);
  document.querySelectorAll(".movie-card").forEach((c) => c.classList.toggle("active", c.dataset.id === id));
  if (scroll) $("#watch").scrollIntoView({ behavior: "smooth" });
}

player.addEventListener("error", () => { if (player.src) toast("Can't stream this file. Try a browser-compatible MP4, or download the original file."); });

async function applySubtitles(movie) {
  [...player.querySelectorAll("track")].forEach((t) => t.remove());
  if (!movie) return;
  if (currentSubtitleMode === "off") return;
  if (currentSubtitleMode === "embedded") {
    // Native browser subtitle tracks can be supplied by the backend as subtitleTracks.
    (movie.subtitleTracks || []).forEach((track) => {
      const elTrack = document.createElement("track");
      elTrack.kind = "subtitles"; elTrack.label = track.label || track.lang; elTrack.srclang = track.lang; elTrack.src = track.src;
      player.appendChild(elTrack);
    });
    return;
  }
  if (!isPremium()) return;
  if (!USE_BACKEND) {
    toast("AI subtitles need a subtitle-generation backend. The Premium control is ready for API integration.");
    return;
  }
  const language = prompt("AI subtitle language (for example: en, ur, es, fr, de):", "en");
  if (!language) return;
  try {
    toast("✨ Generating AI subtitles…");
    const result = await Backend.generateSubtitle(movie.id, language.trim());
    if (result.vttUrl) {
      const track = document.createElement("track"); track.kind = "subtitles"; track.label = result.label || language; track.srclang = language; track.src = result.vttUrl; player.appendChild(track); track.default = true;
      toast(`AI subtitles ready: ${result.label || language}`);
    } else toast("Subtitle job created. Refresh when the generated track is ready.");
  } catch (err) { toast(err.message); }
}

$("#chips").addEventListener("click", (e) => {
  const c = e.target.closest(".chip"); if (!c) return;
  filter = c.dataset.filter;
  document.querySelectorAll(".chip").forEach((x) => x.classList.toggle("active", x === c));
  render();
});

/* ================= YOUTUBE-STYLE PUBLISH STUDIO ================= */
const modal = $("#uploadModal"), form = $("#uploadForm"), fileInput = $("#movieFile"), dz = $("#dropzone"), aiGeneratedPublish = $("#aiGeneratedPublish");
const coverModes = [...document.querySelectorAll(".cover-mode")];
const coverPanels = [...document.querySelectorAll(".cover-panel")];
const coverFrameVideo = $("#coverFrameVideo");
const coverFramePosition = $("#coverFramePosition");
const coverTimeValue = $("#coverTimeValue");
const coverImageFile = $("#coverImageFile");
const captureFrameBtn = $("#captureFrameBtn");
let coverState = { type: "letter", blob: null, objectUrl: "", gradient: 0, letter: "M", sourceName: "" };
const publishPanels = [...document.querySelectorAll(".publish-panel")];
const publishSteps = [...document.querySelectorAll(".publish-step")];
const stepLines = [...document.querySelectorAll(".step-line")];
let publishStep = 1;

$("#modeNote").textContent = USE_BACKEND
  ? "Private keeps your movie to your account. Public makes it discoverable. Premium processing can unlock more quality and AI subtitle options when your server is connected."
  : "Demo mode: the uploaded movie is saved in this browser only. Run the included server for cross-device publishing, accounts, Krea generation and public distribution.";

function setCoverMode(mode) {
  coverState.type = mode;
  coverModes.forEach((button) => button.classList.toggle("active", button.dataset.coverMode === mode));
  coverPanels.forEach((panel) => panel.classList.toggle("active", panel.dataset.coverPanel === mode));
  updateCoverPreview();
}

function revokeCoverStateUrl() {
  if (coverState.objectUrl) { URL.revokeObjectURL(coverState.objectUrl); coverState.objectUrl = ""; }
}

function setCoverBlob(blob, type, name = "cover.png") {
  revokeCoverStateUrl();
  coverState.blob = blob || null;
  coverState.type = type;
  coverState.sourceName = name;
  if (blob) coverState.objectUrl = URL.createObjectURL(blob);
  updateCoverPreview();
}

function updateCoverPreview() {
  const title = $("#movieTitle").value.trim() || "Your movie";
  const letter = title.charAt(0).toUpperCase() || "M";
  coverState.letter = letter;
  $("#coverLetter").textContent = letter;
  $("#coverLetterPreview").style.backgroundImage = gradients[Math.abs(coverState.gradient) % gradients.length];
  const preview = $("#publishPreview");
  preview.style.backgroundImage = "none";
  preview.classList.remove("cover-preview-image");
  const existing = preview.querySelector(".cover-preview-bg");
  if (existing) existing.remove();
  if (coverState.blob && coverState.objectUrl) {
    const bg = document.createElement("div");
    bg.className = "cover-preview-bg";
    bg.style.backgroundImage = `url("${coverState.objectUrl}")`;
    preview.prepend(bg);
    preview.classList.add("cover-preview-image");
    $("#previewIcon").textContent = "🖼️";
  } else {
    preview.style.backgroundImage = gradients[Math.abs(coverState.gradient) % gradients.length];
    $("#previewIcon").textContent = letter;
  }
  const summary = $("#summaryThumb");
  summary.style.backgroundImage = "none";
  summary.classList.remove("cover-preview-image");
  const summaryBg = summary.querySelector(".cover-preview-bg");
  if (summaryBg) summaryBg.remove();
  if (coverState.blob && coverState.objectUrl) {
    const bg = document.createElement("div"); bg.className = "cover-preview-bg"; bg.style.backgroundImage = `url("${coverState.objectUrl}")`; summary.prepend(bg); summary.classList.add("cover-preview-image"); summary.textContent = "";
  } else { summary.style.backgroundImage = gradients[Math.abs(coverState.gradient) % gradients.length]; summary.textContent = letter; }
}

function resetCoverState() {
  revokeCoverStateUrl();
  coverState = { type: "letter", blob: null, objectUrl: "", gradient: 0, letter: "M", sourceName: "" };
  coverModes.forEach((button) => button.classList.toggle("active", button.dataset.coverMode === "letter"));
  coverPanels.forEach((panel) => panel.classList.toggle("active", panel.dataset.coverPanel === "letter"));
  document.querySelectorAll(".gradient-swatch").forEach((b) => b.classList.toggle("active", b.dataset.gradient === "0"));
  if (coverImageFile) coverImageFile.value = "";
  if (coverFrameVideo) { coverFrameVideo.pause(); coverFrameVideo.removeAttribute("src"); coverFrameVideo.load(); }
  if (coverFramePosition) { coverFramePosition.value = "10"; coverFramePosition.disabled = true; }
  if (coverTimeValue) coverTimeValue.textContent = "10%";
  updateCoverPreview();
}

function loadCoverFrameSource(file) {
  if (!coverFrameVideo) return;
  try {
    const url = URL.createObjectURL(file);
    coverFrameVideo.dataset.sourceUrl = url;
    coverFrameVideo.src = url;
    coverFrameVideo.load();
  } catch { toast("Could not prepare frame capture."); }
}

async function captureMovieFrame() {
  if (!coverFrameVideo?.src || !Number.isFinite(coverFrameVideo.duration)) { toast("Choose a video that your browser can preview first."); return; }
  try {
    const width = coverFrameVideo.videoWidth || 1280;
    const height = coverFrameVideo.videoHeight || 720;
    const canvas = document.createElement("canvas");
    const maxWidth = 1600;
    const scale = Math.min(1, maxWidth / width);
    canvas.width = Math.max(320, Math.round(width * scale));
    canvas.height = Math.max(180, Math.round(height * scale));
    const ctx = canvas.getContext("2d");
    ctx.drawImage(coverFrameVideo, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/jpeg", 0.9));
    if (!blob) throw new Error("Could not create the frame image.");
    setCoverBlob(blob, "frame", "movie-frame.jpg");
    toast("🎞️ Frame captured as your movie cover.");
  } catch (err) { toast(`Frame capture failed: ${err.message || "unsupported video"}`); }
}

coverModes.forEach((button) => button.addEventListener("click", () => setCoverMode(button.dataset.coverMode)));
document.querySelectorAll(".gradient-swatch").forEach((button) => button.addEventListener("click", () => {
  coverState.gradient = Number(button.dataset.gradient || 0);
  document.querySelectorAll(".gradient-swatch").forEach((b) => b.classList.toggle("active", b === button));
  updateCoverPreview();
}));

if (coverImageFile) coverImageFile.addEventListener("change", () => {
  const file = coverImageFile.files?.[0];
  if (!file) return;
  if (!file.type.startsWith("image/")) { toast("Choose a PNG, JPG, WEBP or AVIF image."); coverImageFile.value = ""; return; }
  setCoverBlob(file, "image", file.name);
  setCoverMode("image");
  toast("🖼️ Custom cover selected.");
});

if (coverFrameVideo) coverFrameVideo.addEventListener("loadedmetadata", () => {
  if (coverFramePosition) coverFramePosition.disabled = false;
  if (coverFramePosition && Number.isFinite(coverFrameVideo.duration)) coverFrameVideo.currentTime = coverFrameVideo.duration * (Number(coverFramePosition.value) / 100);
});
if (coverFramePosition) coverFramePosition.addEventListener("input", () => {
  const pct = Number(coverFramePosition.value);
  coverTimeValue.textContent = `${pct}%`;
  if (Number.isFinite(coverFrameVideo.duration)) { try { coverFrameVideo.currentTime = coverFrameVideo.duration * pct / 100; } catch {} }
});
if (captureFrameBtn) captureFrameBtn.addEventListener("click", captureMovieFrame);

function setPublishStep(step) {
  publishStep = Math.max(1, Math.min(3, step));
  publishPanels.forEach((panel) => panel.classList.toggle("active", Number(panel.dataset.panel) === publishStep));
  publishSteps.forEach((button) => {
    const n = Number(button.dataset.step);
    button.classList.toggle("active", n === publishStep);
    button.classList.toggle("done", n < publishStep);
  });
  stepLines.forEach((line, i) => line.classList.toggle("filled", i < publishStep - 1));
  $("#publishBack").disabled = publishStep === 1;
  $("#publishNext").hidden = publishStep === 3;
  $("#submitUpload").hidden = publishStep !== 3;
  const headings = {
    1: ["Turn your movie into a premiere.", "Pick the movie and give it a little personality."],
    2: ["Decide who gets the premiere.", "Choose visibility in one tap. You can change it later."],
    3: ["Everything looks ready.", "Run the final checks, then launch your movie." ]
  };
  $("#publishHeading").textContent = headings[publishStep][0];
  $("#publishSubheading").textContent = headings[publishStep][1];
}

function openModal() {
  modal.hidden = false;
  form.classList.remove("publishing");
  resetCoverState();
  setPublishStep(1);
  updatePublishSummary();
  animatePublishChecks();
}
function closeModal() {
  if (form.classList.contains("publishing")) return;
  modal.hidden = true;
  form.reset();
  $("#dzText").textContent = "Drop your video here or click to browse";
  $("#previewTitle").textContent = "Your movie preview";
  $("#previewMeta").textContent = "Choose a video to get started";
  $("#progress").hidden = true;
  $("#publishStatus").hidden = true;
  $("#submitUpload").disabled = false;
  resetCoverState();
}
$("#openUpload").onclick = openModal;
$("#closeUpload").onclick = closeModal;
modal.addEventListener("click", (e) => { if (e.target === modal) closeModal(); });
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !modal.hidden) closeModal(); });

function validatePublishStep(step) {
  if (step === 1) {
    const file = fileInput.files[0];
    const title = $("#movieTitle").value.trim();
    if (!file) { toast("🎬 Choose a movie first."); dz.classList.add("over"); setTimeout(() => dz.classList.remove("over"), 700); return false; }
    if (!file.type.startsWith("video/") && !/\.mkv$/i.test(file.name)) { toast("Please choose a video file."); return false; }
    if (!title) { $("#movieTitle").focus(); toast("Give your movie a title first."); return false; }
  }
  if (step === 2 && !form.visibility.value) { toast("Choose who can watch the movie."); return false; }
  return true;
}

function updatePublishSummary() {
  const title = $("#movieTitle").value.trim() || "Your movie";
  const desc = $("#movieDescription").value.trim() || "No description added.";
  const file = fileInput.files[0];
  const visibility = form.visibility.value;
  $("#previewTitle").textContent = file ? title : "Your movie preview";
  $("#previewMeta").textContent = file ? `${file.name} • ${fmtSize(file.size)}` : "Choose a video to get started";
  $("#summaryTitle").textContent = title;
  $("#summaryDescription").textContent = desc;
  $("#visibilityHeroIcon").textContent = visibility === "public" ? "🌐" : "🔒";
  $("#visibilityHeroTitle").textContent = visibility === "public" ? "Anyone can watch" : "Only you can watch";
  $("#visibilityHeroText").textContent = visibility === "public" ? "Your movie will be visible to anyone who can access the library." : "Keep the movie private until you're ready to share it.";
  updateCoverPreview();
}

function animatePublishChecks() {
  const file = fileInput.files[0];
  const rows = {
    file: [!!file, file ? `${file.name} • ${fmtSize(file.size)}` : "Choose a video first"],
    details: [!!$("#movieTitle").value.trim(), $("#movieTitle").value.trim() ? "Title added" : "Waiting for a title"],
    visibility: [!!form.visibility.value, form.visibility.value === "public" ? "Public" : "Private"]
  };
  Object.entries(rows).forEach(([key, [ready, text]], index) => {
    const row = document.querySelector(`.check-row[data-check="${key}"]`);
    if (!row) return;
    row.classList.remove("ready", "error");
    row.classList.toggle("ready", ready);
    row.querySelector("span").textContent = ready ? "✓" : "◌";
    row.querySelector("small").textContent = text;
    row.style.animationDelay = `${index * 110}ms`;
    if (ready) row.animate([{opacity:.2,transform:"translateX(-8px)"},{opacity:1,transform:"translateX(4px)"},{transform:"translateX(0)"}], {duration:520,fill:"both",easing:"cubic-bezier(.2,.9,.3,1.2)",delay:index*100});
  });
}

function pickFile(f) {
  if (!f) return;
  $("#dzText").textContent = f.name + " (" + fmtSize(f.size) + ")";
  if (!$("#movieTitle").value) $("#movieTitle").value = f.name.replace(/\.[^.]+$/, "");
  loadCoverFrameSource(f);
  updatePublishSummary();
  updateCoverPreview();
  animatePublishChecks();
}

fileInput.addEventListener("change", () => pickFile(fileInput.files[0]));
["dragenter", "dragover"].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add("over"); }));
["dragleave", "drop"].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.remove("over"); }));
dz.addEventListener("drop", (e) => { if (e.dataTransfer.files.length) { fileInput.files = e.dataTransfer.files; pickFile(fileInput.files[0]); } });

$("#movieTitle").addEventListener("input", () => { updatePublishSummary(); updateCoverPreview(); animatePublishChecks(); });
$("#movieDescription").addEventListener("input", updatePublishSummary);
document.querySelectorAll('input[name="visibility"]').forEach((input) => input.addEventListener("change", () => { updatePublishSummary(); animatePublishChecks(); }));

$("#publishNext").addEventListener("click", () => {
  if (!validatePublishStep(publishStep)) return;
  updatePublishSummary();
  setPublishStep(publishStep + 1);
  animatePublishChecks();
});
$("#publishBack").addEventListener("click", () => setPublishStep(publishStep - 1));
publishSteps.forEach((button) => button.addEventListener("click", () => {
  const target = Number(button.dataset.step);
  if (target <= publishStep) setPublishStep(target);
}));

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (form.classList.contains("publishing")) return;
  if (!validatePublishStep(1) || !validatePublishStep(2)) { setPublishStep(1); return; }
  updatePublishSummary(); animatePublishChecks();
  const file = fileInput.files[0];
  const meta = { title: $("#movieTitle").value.trim(), description: $("#movieDescription").value.trim(), visibility: form.visibility.value, posterType: coverState.blob ? coverState.type : "letter", posterGradient: coverState.gradient, posterLetter: coverState.letter, coverFile: coverState.blob || null, aiGenerated: !!aiGeneratedPublish?.checked, aiDurationMinutes: 0, aiPrompt: "", aiStyle: "", aiLanguage: "", aiGeneratedAt: aiGeneratedPublish?.checked ? new Date().toISOString() : "" };
  const btn = $("#submitUpload"), prog = $("#progress"), bar = $("#progressBar");
  form.classList.add("publishing");
  btn.disabled = true;
  $("#publishBack").disabled = true;
  prog.hidden = false; prog.classList.toggle("indeterminate", !USE_BACKEND); bar.style.width = "0";
  $("#publishStatus").hidden = false;
  $("#publishStatusTitle").textContent = "Publishing your movie…";
  $("#publishStatusText").textContent = USE_BACKEND ? "Uploading and preparing your movie." : "Saving your movie securely in this browser.";
  const phases = [
    ["Checking the video…", "Making sure your movie is ready to go."],
    ["Uploading your movie…", "Transferring the video to BlueCinema."],
    ["Polishing the premiere…", "Applying your title, description and visibility."],
    ["Your movie is live!", meta.visibility === "public" ? "The premiere is ready for viewers." : "The movie is safely published to your account."]
  ];
  let phaseIndex = 0;
  const phaseTimer = setInterval(() => {
    phaseIndex = Math.min(phaseIndex + 1, phases.length - 1);
    $("#publishStatusTitle").textContent = phases[phaseIndex][0];
    $("#publishStatusText").textContent = phases[phaseIndex][1];
  }, USE_BACKEND ? 900 : 500);
  try {
    await Backend.add(meta, file, (p) => {
      bar.style.width = Math.round(p * 100) + "%";
      if (USE_BACKEND) $("#publishStatusText").textContent = `Uploading… ${Math.round(p * 100)}%`;
    });
    clearInterval(phaseTimer);
    $("#publishStatusTitle").textContent = "Your movie is live!";
    $("#publishStatusText").textContent = meta.visibility === "public" ? "The premiere is ready for viewers." : "The movie is safely published to your library.";
    bar.style.width = "100%";
    $("#publishStatus .status-ring").style.animation = "none";
    $("#publishStatus .status-ring span").textContent = "✓";
    toast(meta.visibility === "private" ? "🔒 Movie published privately" : "🌐 Movie published publicly");
    filter = "all";
    document.querySelectorAll(".chip").forEach((c) => c.classList.toggle("active", c.dataset.filter === "all"));
    await refresh();
    await new Promise((r) => setTimeout(r, 800));
    closeModal();
  } catch (err) {
    clearInterval(phaseTimer);
    $("#publishStatusTitle").textContent = "We couldn't publish that yet.";
    $("#publishStatusText").textContent = err.message || "Upload failed.";
    $("#publishStatus .status-ring").style.animation = "none";
    $("#publishStatus .status-ring span").textContent = "!";
    toast("Upload failed: " + (err.message || "Unknown error"));
    btn.disabled = false; form.classList.remove("publishing");
  }
});



/* ================= AI MOVIE GENERATOR ================= */
const aiModal = $("#aiGeneratorModal");
const aiForm = $("#aiGeneratorForm");
const aiPrompt = $("#aiMoviePrompt");
const aiTitle = $("#aiMovieTitle");
const aiDuration = $("#aiMovieDuration");
const aiStyle = $("#aiMovieStyle");
const aiLanguage = $("#aiMovieLanguage");
const aiAutoSubtitles = $("#aiMovieAutoSubtitles");
function updateAiGeneratorLimits() {
  const premium = isPremium();
  document.querySelectorAll("#aiMovieDuration .premium-option").forEach((o) => { o.disabled = !premium; });
  if (!premium && Number(aiDuration.value) > 30) aiDuration.value = "30";
  $("#aiGeneratorLimit").textContent = premium ? "✦ BluePremium: runtimes above one hour are available, subject to the AI provider's generation limits." : "Free plan: AI movies can be generated up to 30 minutes.";
}
function openAiGenerator() {
  if (!currentUser) { $("#authModal").hidden = false; setAuthMode("signin"); return; }
  aiModal.hidden = false; aiForm.classList.remove("generating"); $("#aiGeneratorStatus").hidden = true; $("#startAiGeneration").disabled = false; updateAiGeneratorLimits();
}
function closeAiGenerator() { if (aiForm.classList.contains("generating")) return; aiModal.hidden = true; }
$("#openAiGenerator").addEventListener("click", openAiGenerator);
$("#closeAiGenerator").addEventListener("click", closeAiGenerator);
$("#closeAiGeneratorBottom").addEventListener("click", closeAiGenerator);
aiModal.addEventListener("click", (e) => { if (e.target === aiModal) closeAiGenerator(); });
aiDuration.addEventListener("change", updateAiGeneratorLimits);

aiForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const duration = Number(aiDuration.value);
  if (!isPremium() && duration > 30) return toast("Free AI generation is capped at 30 minutes.");
  if (isPremium() && duration <= 0) return toast("Choose a valid movie runtime.");
  const payload = { title: aiTitle.value.trim() || "AI Movie", prompt: aiPrompt.value.trim(), durationMinutes: duration, style: aiStyle.value, language: aiLanguage.value, autoSubtitles: aiAutoSubtitles.checked, aiGenerated: true };
  if (!payload.prompt) return toast("Describe the movie you want to generate.");
  const btn = $("#startAiGeneration"), status = $("#aiGeneratorStatus"), title = $("#aiGeneratorStatusTitle"), text = $("#aiGeneratorStatusText");
  aiForm.classList.add("generating"); btn.disabled = true; status.hidden = false;
  const localPhases = [
    ["Reading your idea…", "Turning the prompt into a production plan."],
    ["Directing scenes…", "Generating shots, characters and movement."],
    ["Rendering the movie…", "The AI backend is assembling the final video."],
    ["Preparing publication…", "Adding the AI GENERATED label and metadata."]
  ];
  let phase = 0; title.textContent = localPhases[0][0]; text.textContent = localPhases[0][1];
  const timer = setInterval(() => { phase = Math.min(phase + 1, localPhases.length - 1); title.textContent = localPhases[phase][0]; text.textContent = localPhases[phase][1]; }, 1400);
  try {
    const result = await Backend.generateMovie(payload);
    clearInterval(timer);
    if (result.jobId && USE_BACKEND) {
      title.textContent = "Krea is rendering your movie…";
      text.textContent = result.message || "BlueCinema is generating the film in Krea and assembling the clips.";
      toast("✨ Krea generation started.");
      let finished = false;
      while (!finished) {
        await new Promise((resolve) => setTimeout(resolve, 5000));
        const job = await Backend.getAiMovieJob(result.jobId);
        if (job.status === "completed") {
          finished = true;
          title.textContent = "Your AI movie is ready!";
          text.textContent = "Krea finished the render and BlueCinema assembled the final movie. It is tagged AI GENERATED.";
          if (job.movie) {
            job.movie.aiGenerated = true;
            job.movie.aiGeneratedAt = job.movie.aiGeneratedAt || new Date().toISOString();
            job.movie.mine = true;
            job.movie.ownerName = job.movie.ownerName || currentUser?.name || "You";
            library = [job.movie, ...library];
            render();
          }
          toast("🎬 Your Krea movie is ready.");
        } else if (["failed", "cancelled"].includes(job.status)) {
          throw new Error(job.message || "Krea could not finish this movie.");
        } else {
          const pct = Number.isFinite(job.progress) ? Math.round(job.progress * 100) : null;
          text.textContent = pct == null ? "Krea is still rendering and BlueCinema is assembling the final movie…" : `Krea rendering progress: ${pct}%`;
        }
      }
    } else {
      title.textContent = "Generation request accepted!";
      text.textContent = result.message || "Your AI movie is being rendered.";
      toast("✨ Krea generation started.");
      if (result.movie) { result.movie.aiGenerated = true; result.movie.aiGeneratedAt = result.movie.aiGeneratedAt || new Date().toISOString(); result.movie.mine = result.movie.mine !== false; result.movie.ownerName = result.movie.ownerName || currentUser?.name || "You"; library = [result.movie, ...library]; render(); }
    }
    setTimeout(() => { aiForm.classList.remove("generating"); btn.disabled = false; aiModal.hidden = true; }, 1200);
  } catch (err) {
    clearInterval(timer);
    title.textContent = "AI generation needs a backend.";
    text.textContent = err.message || "Connect your AI video generation service to render the movie.";
    toast(err.message || "AI generation is unavailable.");
    setTimeout(() => { aiForm.classList.remove("generating"); btn.disabled = false; }, 800);
  }
});

/* ================= EFFECTS + PWA ================= */
document.addEventListener("click", (e) => {
  const b = e.target.closest(".btn"); if (!b) return;
  const r = b.getBoundingClientRect(), s = Math.max(r.width, r.height) / 4, d = el("span", "ripple");
  d.style.cssText = `width:${s}px;height:${s}px;left:${e.clientX - r.left - s / 2}px;top:${e.clientY - r.top - s / 2}px`;
  b.appendChild(d); setTimeout(() => d.remove(), 600);
});
const io = new IntersectionObserver((es) => es.forEach((x) => x.isIntersecting && (x.target.classList.add("in"), io.unobserve(x.target))), { threshold: .1 });
document.querySelectorAll(".reveal").forEach((n) => io.observe(n));
if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost")) navigator.serviceWorker.register("./sw.js").catch(() => {});

/* ================= INIT ================= */
$("#year").textContent = new Date().getFullYear();
setPlan(plan, false);
updateSiteFavicon();
(async () => {
  const signedIn = await bootstrapAuth();
  if (!signedIn) return;
  await refresh();
  if (library.length) await playMovie(library[0].id, false);
})();
