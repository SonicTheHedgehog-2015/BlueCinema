// Static-file mode. When BlueCinema is served by server.js, /config.js is generated dynamically
// with server mode enabled, so the front end automatically uses the backend APIs.
window.BLUECINEMA_SERVER_MODE = false;
window.BLUECINEMA_API_URL = "";
