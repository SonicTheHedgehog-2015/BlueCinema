import express from "express";
import multer from "multer";
import dotenv from "dotenv";
import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { existsSync, createReadStream } from "node:fs";
import { execFile } from "node:child_process";
import { promisify } from "node:util";


dotenv.config();

const app = express();
const execFileAsync = promisify(execFile);
const PORT = Number(process.env.PORT || 3000);
const ROOT = process.cwd();
const DATA_DIR = path.join(ROOT, "data");
const UPLOAD_DIR = path.join(DATA_DIR, "uploads");
const GENERATED_DIR = path.join(DATA_DIR, "generated");
const ACCOUNTS_FILE = path.join(DATA_DIR, "accounts.json");
const MOVIES_FILE = path.join(DATA_DIR, "movies.json");
const KREA_API_KEY = process.env.KREA_API_KEY || "";
const KREA_VIDEO_MODEL = process.env.KREA_VIDEO_MODEL || "bytedance/seedance-2-5";
const OWNER_PREMIUM_EMAILS = new Set(
  (process.env.OWNER_PREMIUM_EMAILS || "blackholedevelopers2015@gmail.com,muhammadsarimumair22@gmail.com")
    .split(",").map((x) => x.trim().toLowerCase()).filter(Boolean)
);
const FREE_MAX_MINUTES = 30;
const PREMIUM_MIN_MINUTES = 61;
const PREMIUM_MAX_MINUTES = Number(process.env.PREMIUM_MAX_MINUTES || 120);
const KREA_SEGMENT_SECONDS = Math.min(30, Number(process.env.KREA_SEGMENT_SECONDS || 30));
const sessions = new Map();
const aiJobs = new Map();
let ffmpegChecked = false;

await fs.mkdir(UPLOAD_DIR, { recursive: true });
await fs.mkdir(GENERATED_DIR, { recursive: true });
for (const [file, fallback] of [[ACCOUNTS_FILE, []], [MOVIES_FILE, []]]) {
  if (!existsSync(file)) await fs.writeFile(file, JSON.stringify(fallback, null, 2));
}

app.disable("x-powered-by");
app.use(express.json({ limit: "2mb" }));

function parseCookies(req) {
  const raw = req.headers.cookie || "";
  return Object.fromEntries(raw.split(";").map((part) => part.trim()).filter(Boolean).map((part) => {
    const i = part.indexOf("=");
    return i < 0 ? [part, ""] : [decodeURIComponent(part.slice(0, i)), decodeURIComponent(part.slice(i + 1))];
  }));
}

function setSessionCookie(res, sid) {
  res.setHeader("Set-Cookie", `bluecinema_sid=${encodeURIComponent(sid)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000`);
}
function clearSessionCookie(res) {
  res.setHeader("Set-Cookie", "bluecinema_sid=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0");
}

async function readJson(file) {
  return JSON.parse(await fs.readFile(file, "utf8"));
}
async function writeJson(file, value) {
  await fs.writeFile(file, JSON.stringify(value, null, 2));
}

function normalizeEmail(email) {
  return String(email || "").trim().toLowerCase();
}
function isOwnerPremium(email) {
  return OWNER_PREMIUM_EMAILS.has(normalizeEmail(email));
}
function publicUser(account) {
  return { name: account.name, email: account.email };
}
function planFor(account) {
  return isOwnerPremium(account?.email) || account?.plan === "premium" ? "premium" : "free";
}

function hashPassword(password, salt = crypto.randomBytes(16).toString("hex")) {
  const hash = crypto.scryptSync(String(password), salt, 64).toString("hex");
  return `${salt}:${hash}`;
}
function verifyPassword(password, stored) {
  const [salt, hash] = String(stored || "").split(":");
  if (!salt || !hash) return false;
  const candidate = crypto.scryptSync(String(password), salt, 64).toString("hex");
  return crypto.timingSafeEqual(Buffer.from(candidate, "hex"), Buffer.from(hash, "hex"));
}

async function requireAuth(req, res, next) {
  const sid = parseCookies(req).bluecinema_sid;
  const accountId = sid ? sessions.get(sid) : null;
  if (!accountId) return res.status(401).json({ message: "Sign in required." });
  const accounts = await readJson(ACCOUNTS_FILE);
  const account = accounts.find((a) => a.id === accountId);
  if (!account) return res.status(401).json({ message: "Session expired. Please sign in again." });
  req.account = account;
  next();
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) => cb(null, `${crypto.randomUUID()}${path.extname(file.originalname || ".mp4")}`)
});
const upload = multer({ storage, limits: { fileSize: 20 * 1024 * 1024 * 1024, files: 2 } });
const uploadMovieAssets = upload.fields([{ name: "file", maxCount: 1 }, { name: "poster", maxCount: 1 }]);

function movieView(req, movie) {
  return {
    ...movie,
    mine: movie.ownerId === req.account?.id,
    size: movie.sizeBytes ? `${(movie.sizeBytes / 1e6).toFixed(1)} MB` : movie.size,
    streamUrl: movie.filePath ? `/media/movies/${movie.id}` : movie.streamUrl,
    downloadUrl: movie.filePath ? `/media/movies/${movie.id}?download=1` : movie.downloadUrl,
    posterUrl: movie.posterPath ? `/media/posters/${movie.id}` : ""
  };
}

app.get("/config.js", (_req, res) => {
  res.type("application/javascript").send("window.BLUECINEMA_SERVER_MODE=true;window.BLUECINEMA_API_URL='';");
});

app.post("/api/auth/register", async (req, res) => {
  const name = String(req.body?.name || "").trim();
  const email = normalizeEmail(req.body?.email);
  const password = String(req.body?.password || "");
  if (!name || !email || password.length < 8) return res.status(400).json({ message: "Name, valid email and an 8+ character password are required." });
  const accounts = await readJson(ACCOUNTS_FILE);
  if (accounts.some((a) => a.email === email)) return res.status(409).json({ message: "An account with this email already exists." });
  const account = { id: crypto.randomUUID(), name, email, passwordHash: hashPassword(password), plan: isOwnerPremium(email) ? "premium" : "free", createdAt: new Date().toISOString() };
  accounts.push(account); await writeJson(ACCOUNTS_FILE, accounts);
  const sid = crypto.randomUUID(); sessions.set(sid, account.id); setSessionCookie(res, sid);
  res.json({ user: publicUser(account), plan: planFor(account) });
});

app.post("/api/auth/login", async (req, res) => {
  const email = normalizeEmail(req.body?.email);
  const password = String(req.body?.password || "");
  const accounts = await readJson(ACCOUNTS_FILE);
  const account = accounts.find((a) => a.email === email);
  if (!account || !verifyPassword(password, account.passwordHash)) return res.status(401).json({ message: "Incorrect email or password." });
  const sid = crypto.randomUUID(); sessions.set(sid, account.id); setSessionCookie(res, sid);
  res.json({ user: publicUser(account), plan: planFor(account) });
});

app.post("/api/auth/logout", (req, res) => {
  const sid = parseCookies(req).bluecinema_sid;
  if (sid) sessions.delete(sid);
  clearSessionCookie(res);
  res.json({ ok: true });
});

app.get("/api/auth/session", async (req, res) => {
  const sid = parseCookies(req).bluecinema_sid;
  const accountId = sid ? sessions.get(sid) : null;
  if (!accountId) return res.json({ authenticated: false });
  const accounts = await readJson(ACCOUNTS_FILE);
  const account = accounts.find((a) => a.id === accountId);
  if (!account) return res.json({ authenticated: false });
  res.json({ authenticated: true, user: publicUser(account), plan: planFor(account) });
});

app.get("/api/me/subscription", requireAuth, (req, res) => {
  res.json({ plan: planFor(req.account), status: "active" });
});

app.get("/api/movies", requireAuth, async (req, res) => {
  const movies = await readJson(MOVIES_FILE);
  res.json(movies.filter((m) => m.visibility === "public" || m.ownerId === req.account.id).map((m) => movieView(req, m)));
});

app.post("/api/movies", requireAuth, uploadMovieAssets, async (req, res) => {
  const movieFile = req.files?.file?.[0];
  const posterFile = req.files?.poster?.[0];
  if (!movieFile) return res.status(400).json({ message: "Movie file is required." });
  const accounts = await readJson(ACCOUNTS_FILE);
  const movies = await readJson(MOVIES_FILE);
  const aiGenerated = req.body.aiGenerated === "1";
  const movie = {
    id: crypto.randomUUID(), title: String(req.body.title || movieFile.originalname).trim(), description: String(req.body.description || "").trim(),
    visibility: req.body.visibility === "public" ? "public" : "private", ownerId: req.account.id, ownerName: req.account.name,
    publishedAt: new Date().toISOString(), filePath: movieFile.path, fileName: movieFile.originalname, sizeBytes: movieFile.size,
    posterPath: posterFile?.path || "", posterMimeType: posterFile?.mimetype || "", posterType: posterFile ? String(req.body.posterType || "image") : "letter", posterGradient: Number(req.body.posterGradient || 0), posterLetter: String(req.body.posterLetter || String(req.body.title || "M").charAt(0)).slice(0,1).toUpperCase(),
    aiGenerated, aiPrompt: String(req.body.aiPrompt || ""), aiDurationMinutes: Number(req.body.aiDurationMinutes || 0), aiStyle: String(req.body.aiStyle || ""), aiLanguage: String(req.body.aiLanguage || ""), aiGeneratedAt: String(req.body.aiGeneratedAt || "")
  };
  movies.push(movie); await writeJson(MOVIES_FILE, movies);
  res.status(201).json({ movie: movieView(req, movie) });
});

app.patch("/api/movies/:id", requireAuth, async (req, res) => {
  const movies = await readJson(MOVIES_FILE);
  const movie = movies.find((m) => m.id === req.params.id && m.ownerId === req.account.id);
  if (!movie) return res.status(404).json({ message: "Movie not found." });
  movie.visibility = req.body?.visibility === "public" ? "public" : "private";
  await writeJson(MOVIES_FILE, movies); res.json({ movie: movieView(req, movie) });
});

app.delete("/api/movies/:id", requireAuth, async (req, res) => {
  const movies = await readJson(MOVIES_FILE);
  const idx = movies.findIndex((m) => m.id === req.params.id && m.ownerId === req.account.id);
  if (idx < 0) return res.status(404).json({ message: "Movie not found." });
  const [movie] = movies.splice(idx, 1); await writeJson(MOVIES_FILE, movies);
  if (movie.filePath) await fs.rm(movie.filePath, { force: true }).catch(() => {});
  if (movie.posterPath) await fs.rm(movie.posterPath, { force: true }).catch(() => {});
  res.json({ ok: true });
});


app.get("/media/posters/:id", async (req, res) => {
  const movies = await readJson(MOVIES_FILE);
  const movie = movies.find((m) => m.id === req.params.id);
  if (!movie?.posterPath || !existsSync(movie.posterPath)) return res.sendStatus(404);
  const sid = parseCookies(req).bluecinema_sid;
  const ownerId = sid ? sessions.get(sid) : null;
  if (movie.visibility !== "public" && ownerId !== movie.ownerId) return res.sendStatus(403);
  res.setHeader("Cache-Control", "public, max-age=3600");
  if (movie.posterMimeType) res.setHeader("Content-Type", movie.posterMimeType);
  createReadStream(movie.posterPath).pipe(res);
});

app.get("/media/movies/:id", async (req, res) => {
  const movies = await readJson(MOVIES_FILE);
  const movie = movies.find((m) => m.id === req.params.id);
  if (!movie?.filePath || !existsSync(movie.filePath)) return res.sendStatus(404);
  const sid = parseCookies(req).bluecinema_sid;
  const ownerId = sid ? sessions.get(sid) : null;
  if (movie.visibility !== "public" && ownerId !== movie.ownerId) return res.sendStatus(403);
  if (req.query.download) res.setHeader("Content-Disposition", `attachment; filename*=UTF-8''${encodeURIComponent(movie.fileName || "movie.mp4")}`);
  res.setHeader("Content-Type", "video/mp4");
  createReadStream(movie.filePath).pipe(res);
});

async function ensureFfmpeg() {
  if (ffmpegChecked) return;
  await execFileAsync("ffmpeg", ["-version"]);
  ffmpegChecked = true;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const terminalStates = new Set(["completed", "failed", "cancelled"]);

async function kreaCreateVideo(prompt, durationSeconds) {
  if (!KREA_API_KEY) throw new Error("KREA_API_KEY is not configured on the BlueCinema server.");
  const endpoint = `https://api.krea.ai/generate/video/${KREA_VIDEO_MODEL}`;
  const response = await fetch(endpoint, {
    method: "POST",
    headers: { Authorization: `Bearer ${KREA_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ prompt, duration: durationSeconds, resolution: "1080p", aspect_ratio: "16:9", generate_audio: true })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data.job_id) throw new Error(data.message || `Krea rejected the generation request (${response.status}).`);
  return data.job_id;
}

async function kreaWait(jobId) {
  while (true) {
    const response = await fetch(`https://api.krea.ai/jobs/${encodeURIComponent(jobId)}`, { headers: { Authorization: `Bearer ${KREA_API_KEY}` } });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.message || `Krea job lookup failed (${response.status}).`);
    if (terminalStates.has(data.status)) return data;
    await sleep(5000);
  }
}

async function downloadFile(url, destination) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Could not download Krea's result (${response.status}).`);
  const buffer = Buffer.from(await response.arrayBuffer());
  await fs.writeFile(destination, buffer);
}

function segmentBeat(index, total) {
  const p = total <= 1 ? 0 : index / (total - 1);
  if (p < 0.12) return "opening: establish the world, characters, stakes and visual language";
  if (p < 0.45) return "rising action: develop the central conflict and escalate events";
  if (p < 0.70) return "midpoint: reveal a meaningful complication or discovery";
  if (p < 0.90) return "climax approach: intensify the conflict toward its decisive moment";
  return "resolution: deliver the emotional payoff and a satisfying ending beat";
}

async function runAiMovieJob(job, req) {
  const segments = Math.ceil(job.durationMinutes * 60 / KREA_SEGMENT_SECONDS);
  job.totalSegments = segments;
  job.status = "processing";
  const tempDir = path.join(DATA_DIR, "tmp", job.id);
  await fs.mkdir(tempDir, { recursive: true });
  const clipPaths = [];
  try {
    await ensureFfmpeg();
    for (let i = 0; i < segments; i += 1) {
      const remaining = job.durationMinutes * 60 - i * KREA_SEGMENT_SECONDS;
      const durationSeconds = Math.max(1, Math.min(KREA_SEGMENT_SECONDS, remaining));
      const prompt = [
        job.prompt,
        `Style: ${job.style}. Primary language: ${job.language}.`,
        `This is scene ${i + 1} of ${segments}. Keep the same protagonist design, wardrobe, world rules, cinematography and tone throughout the entire film. ${segmentBeat(i, segments)}.`,
        "Create a self-contained cinematic shot that can be edited directly after the previous shot. Avoid titles, captions, watermarks and logos."
      ].join(" ");
      const kreaJobId = await kreaCreateVideo(prompt, durationSeconds);
      const result = await kreaWait(kreaJobId);
      if (result.status !== "completed" || !result.result?.urls?.[0]) throw new Error(`Krea scene ${i + 1} failed.`);
      const clipPath = path.join(tempDir, `clip-${String(i + 1).padStart(4, "0")}.mp4`);
      await downloadFile(result.result.urls[0], clipPath);
      clipPaths.push(clipPath);
      job.progress = (i + 1) / segments;
      job.currentScene = i + 1;
      job.message = `Krea rendered scene ${i + 1} of ${segments}.`;
    }

    job.message = "Krea clips complete. BlueCinema is assembling the final movie.";
    const concatList = path.join(tempDir, "concat.txt");
    const concatText = clipPaths.map((p) => `file '${p.replaceAll("'", "'\\''")}'`).join("\n");
    await fs.writeFile(concatList, concatText + "\n");
    const finalId = crypto.randomUUID();
    const outputPath = path.join(GENERATED_DIR, `${finalId}.mp4`);
    try {
      await execFileAsync("ffmpeg", ["-y", "-f", "concat", "-safe", "0", "-i", concatList, "-c", "copy", outputPath]);
    } catch {
      await execFileAsync("ffmpeg", ["-y", "-f", "concat", "-safe", "0", "-i", concatList, "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-c:a", "aac", "-b:a", "192k", outputPath]);
    }
    const stat = await fs.stat(outputPath);
    const movies = await readJson(MOVIES_FILE);
    const movie = {
      id: finalId, title: job.title || "AI Movie", description: job.prompt, visibility: "private", ownerId: req.account.id, ownerName: req.account.name,
      publishedAt: new Date().toISOString(), filePath: outputPath, fileName: `${(job.title || "ai-movie").replace(/[^a-z0-9-_ ]/gi, "").trim() || "ai-movie"}.mp4`, sizeBytes: stat.size,
      aiGenerated: true, aiPrompt: job.prompt, aiDurationMinutes: job.durationMinutes, aiStyle: job.style, aiLanguage: job.language, aiGeneratedAt: new Date().toISOString(), aiSubtitles: false
    };
    movies.push(movie); await writeJson(MOVIES_FILE, movies);
    job.movie = movieView(req, movie);
    job.status = "completed"; job.progress = 1; job.message = "Krea finished the movie and BlueCinema assembled the final file.";
  } catch (error) {
    job.status = "failed"; job.message = error?.message || "Krea movie generation failed.";
  } finally {
    await fs.rm(tempDir, { recursive: true, force: true }).catch(() => {});
  }
}

app.post("/api/ai/movies/generate", requireAuth, async (req, res) => {
  const plan = planFor(req.account);
  const durationMinutes = Number(req.body?.durationMinutes || 0);
  const prompt = String(req.body?.prompt || "").trim();
  const style = String(req.body?.style || "Cinematic");
  const language = String(req.body?.language || "en");
  const autoSubtitles = !!req.body?.autoSubtitles;
  if (!prompt) return res.status(400).json({ message: "A movie concept is required." });
  if (!Number.isFinite(durationMinutes) || durationMinutes <= 0) return res.status(400).json({ message: "Choose a valid runtime." });
  if (plan === "free" && durationMinutes > FREE_MAX_MINUTES) return res.status(403).json({ message: "Free AI movies are limited to 30 minutes." });
  if (plan === "premium" && (durationMinutes < PREMIUM_MIN_MINUTES || durationMinutes > PREMIUM_MAX_MINUTES)) return res.status(403).json({ message: `BluePremium AI movies must be ${PREMIUM_MIN_MINUTES}-${PREMIUM_MAX_MINUTES} minutes in this build.` });
  if (!KREA_API_KEY) return res.status(503).json({ message: "Krea is not connected yet. Add KREA_API_KEY to the server environment." });
  if (autoSubtitles) {
    // Krea generates synchronized audio, but subtitle transcription is a separate service in this stack.
    // Keep the request accepted and mark subtitles for a later transcription step.
  }
  try { await ensureFfmpeg(); } catch { return res.status(503).json({ message: "FFmpeg is required on the BlueCinema server to assemble long Krea movies." }); }

  const job = { id: crypto.randomUUID(), status: "queued", progress: 0, currentScene: 0, totalSegments: 0, message: "Queued for Krea rendering.", ownerId: req.account.id, title: String(req.body?.title || "AI Movie"), prompt, durationMinutes, style, language, autoSubtitles, createdAt: new Date().toISOString() };
  aiJobs.set(job.id, job);
  runAiMovieJob(job, req).catch(() => {});
  res.status(202).json({ jobId: job.id, message: "Krea generation started. BlueCinema will assemble the completed clips automatically." });
});

app.get("/api/ai/movies/jobs/:id", requireAuth, (req, res) => {
  const job = aiJobs.get(req.params.id);
  if (!job || job.ownerId !== req.account.id) return res.status(404).json({ message: "AI job not found." });
  res.json({ status: job.status, progress: job.progress, currentScene: job.currentScene, totalSegments: job.totalSegments, message: job.message, movie: job.status === "completed" ? job.movie : undefined });
});

app.post("/api/movies/:id/subtitles/generate", requireAuth, (_req, res) => {
  res.status(501).json({ message: "Subtitle transcription is not connected yet. Krea is handling movie generation; connect a transcription provider for AI subtitles." });
});

app.get("/", (_req, res) => res.sendFile(path.join(ROOT, "index.html")));
app.use(express.static(ROOT, { index: "index.html", extensions: ["html"] }));

app.listen(PORT, () => {
  console.log(`BlueCinema server running at http://localhost:${PORT}`);
  console.log(`Krea model: ${KREA_VIDEO_MODEL}`);
  console.log(`Owner Premium accounts: ${[...OWNER_PREMIUM_EMAILS].join(", ")}`);
});
