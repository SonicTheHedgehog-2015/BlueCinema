# BlueCinema – Premium-enabled build

## What was added

- Free plan: UI cap of 720p / 30 FPS.
- BluePremium: $15/month product tier, with controls up to 8K / 150 FPS on supported devices.
- Premium subtitle-language picker with AI subtitle backend hook.
- Device capability messaging so the UI does not promise more than the browser/device can reasonably handle.
- OS-aware app installation.
- Progressive Web App (PWA) manifest, service worker and app icons so BlueCinema can actually be installed from supported browsers.
- Native installer hooks for Windows, Linux, macOS and Android. Put real signed installers at the URLs in `NATIVE_INSTALLERS` when you have them.
- The IndexedDB version fix from the previous build remains in place.

## Important production requirement

The browser cannot securely enforce subscriptions, transcode movies to 8K/150 FPS, or generate speech-to-text subtitles by itself. Production enforcement belongs on your server.

Set `API_URL` in `script.js` and implement these endpoints:

- `GET /api/me/subscription`
- `GET /api/movies`
- `POST /api/movies`
- `PATCH /api/movies/:id`
- `DELETE /api/movies/:id`
- `POST /api/movies/:id/subtitles/generate`
- `POST /api/billing/create-checkout-session` (or provide your hosted checkout URL)

Movie records should expose optional quality variants such as:

- `stream720Url`
- `stream1080Url`
- `stream1440Url`
- `stream2160Url`
- `stream4320Url`
- `subtitleTracks`

The server should enforce the plan limits even if someone edits the browser JavaScript.

## Real payments

Set `SUBSCRIPTION.checkoutUrl` to your real Stripe/PayPal hosted checkout URL, or replace `upgradePlan()` with your authenticated checkout-session flow.

## App downloads

The main **Install BlueCinema** button uses the browser's real PWA installation prompt where supported. iPhone/iPad users can use **Share → Add to Home Screen**.

The platform-specific buttons are ready for native builds. Set the appropriate `NATIVE_INSTALLERS` URL in `script.js` when signed `.exe`, `.dmg`, Linux package/AppImage, or Android APK files are available.


## Additional features in this build

- Required sign-in gate with local demo authentication and backend auth hooks.
- Library search by title/description.
- Custom movie right-click menu with play, open, download, copy link, hide, and owner-only permanent delete actions.
- Hidden movies can be restored with the Reset hidden button.
- Audio boost control (100%–250%) using Web Audio when the source/browser permits it, with dynamic compression to reduce clipping.
- ChromeOS detection and a downloadable `bluecinema-chromeos.deb` package for the Linux environment.

### ChromeOS .deb

The included `.deb` packages this static BlueCinema build as a local launcher. On ChromeOS, enable the Linux development environment, download the `.deb`, and install it with `sudo apt install ./bluecinema-chromeos.deb`. The launcher serves the bundled site locally and opens it in Chromium/Chrome app mode.

### Sign-in production contract

When `API_URL` is configured, the frontend expects:
- `GET /api/auth/session`
- `POST /api/auth/login`
- `POST /api/auth/register`
- `POST /api/auth/logout`

The browser-only demo sign-in is for local testing and is not a replacement for server-side authentication.

## Public movie information and shared publishing

Public movies are represented with a safe public `ownerName`, description, title, visibility and publication date. The frontend displays this information on public cards and in the Movie Information dialog.

For cross-device/cross-user publishing, configure `API_URL` to a backend. The `/api/movies` endpoint should return every public movie plus the current user's private movies, while the upload endpoint should derive the display name from the authenticated account rather than trusting a client-supplied identity. Private movies must never be returned to another account.

The static/demo mode intentionally keeps uploads inside the current browser and cannot make a movie appear on a different device without a server.

## v4.1 repair
The previous build had a startup JavaScript error caused by calling the selector helper with `document` instead of a selector string. That prevented later event handlers, including Upload, from being registered. This build fixes that line and bumps the service-worker cache so stale broken JavaScript is not reused.


## New in v6

- Owner allowlist: `blackholedevelopers2015@gmail.com` and `muhammadsarimumair22@gmail.com` receive BluePremium in the client demo. Mirror this allowlist on the backend for real billing bypass/entitlement.
- AI Movie Studio UI with Free <=30 minute generation and BluePremium >60 minute options. Real rendering requires `POST /api/ai/movies/generate` and an AI video provider.
- AI-generated movies are tagged `AI GENERATED` in the library and have a dedicated right-click menu.
- Movie search also matches title, description, owner name and AI metadata; `/` focuses the search box.
- Favicons dynamically switch between the supplied BlueCinema and BluePremium logo URLs. The supplied Kommodo image URLs are time-limited, so replace them with permanent hosted copies for production.

## Owner accounts / free subscription bypass

In the demo client, these two emails are treated as BluePremium owners:
- blackholedevelopers2015@gmail.com
- muhammadsarimumair22@gmail.com

For production, enforce the same entitlement on the backend before creating the checkout session or serving premium/transcoded assets.

## AI Movie Generation endpoint

The frontend calls:
`POST /api/ai/movies/generate`

Payload:
`{ prompt, durationMinutes, style, language, autoSubtitles, aiGenerated: true }`

The endpoint should return a JSON object such as:
`{ message, movie }`

A returned `movie` should include `aiGenerated: true`, `aiPrompt`, `aiDurationMinutes`, `aiStyle`, `aiLanguage`, `aiGeneratedAt`, `ownerName`, `publishedAt`, `streamUrl`, and `downloadUrl` when rendering is complete.

## Krea AI movie generation (v6)

This build now uses the **Krea Video API** as the rendering provider. The server keeps the Krea API key on the backend; it is never exposed to browser JavaScript.

Default model:
- `bytedance/seedance-2-5` (Krea Seedance 2.5)
- One Krea generation is a short clip; BlueCinema assembles those clips into the requested movie runtime.
- A 30-minute movie at 30-second scene chunks requires about 60 Krea generations. A 75-minute movie requires about 150. Long-form generation can therefore be expensive and may take a long time.

Krea's current API flow is:
1. `POST https://api.krea.ai/generate/video/bytedance/seedance-2-5`
2. receive a `job_id`
3. poll `GET https://api.krea.ai/jobs/{job_id}` until completed
4. download the returned video URL
5. BlueCinema stitches the clips with FFmpeg

Krea says API usage is billed separately from Krea's consumer subscription plans, using a separate API balance. See Krea's API documentation and Seedance 2.5 guide for the current model availability and limits.

### Server setup

1. Install Node.js 20+ and FFmpeg.
2. Run `npm install` in this folder.
3. Copy `.env.example` to `.env`.
4. Put your Krea API token in `KREA_API_KEY`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

When `server.js` serves the site, it dynamically enables backend mode through `/config.js`. Opening `index.html` directly still keeps the browser-only demo mode.

### Important

Krea handles video generation and can generate synchronized audio. AI subtitles remain a separate transcription step in this build; the existing subtitle endpoint is deliberately left as a backend hook rather than falsely claiming Krea generated subtitles.

The browser cannot safely hold the Krea API key. Do not put `KREA_API_KEY` into `script.js`, `index.html`, or any publicly served JavaScript file.


## Movie covers / thumbnails

Uploads now support three cover modes in the publish flow: (1) first letter with a selectable animated gradient background, (2) a captured frame from the uploaded movie, or (3) a custom image upload. In server mode the cover image is stored alongside the movie and served from `/media/posters/:id`; in local demo mode it is stored in IndexedDB with the movie.
